
NAME: Dylan Haugee
X500: HAUGE919
HOW-TO: To compile and run my program in a terminal, enter "javac FractalDrawer.java"
and then "java FractalDrawer," which will return a question prompting the user to type
a shape. The canvas will open with a fractal drawing of the appropriate shape, and the
terminal will return the total area and a farewell message.
ASSUMPTIONS: ---
ADDITIONAL FEATURES: If the user input doesn't match the string specifications necessary,
some string is printed poking fun at the user and asking for a valid shape. -1 is returned.
BUGS & DEFECTS: None that I know of lolz
SOURCES: ---

I certify that the  information contained in this README file is complete and accurate.
I have both read and followed the course policies in the "Academic Integrity - Course Policy"
section of the course syllabus.

	- Dylan :)